# 飛書（Feishu/Lark）Bot 設定手順書

このガイドに従って、OpenClaw AIエージェントを飛書に接続します。
所要時間：約5分

---

## Step 1: 飛書開放平台でアプリを作成

1. [飛書開放平台](https://open.feishu.cn/app) にアクセス
2. 「アプリを作成」をクリック
3. アプリ名を入力（例：`AIアシスタント` / `OpenClaw Bot`）
4. 「作成」をクリック

## Step 2: アプリ情報を確認

作成したアプリの **「基本情報」** ページで以下を確認：

- **App ID** → `cli_xxxxxxxxxxxxxxxx`
- **App Secret** → 表示/コピー

これらを `feishu-config.yaml` に設定します。

## Step 3: イベント購読を設定

1. 左メニューから **「イベント購読」** をクリック
2. 「追加」→ 以下を検索して追加：
   - `im.message.receive_v1`（メッセージ受信）
3. POST URLは空欄でOK（WebSocketモードを使用）

## Step 4: 権限を設定

1. 左メニューから **「権限管理」** をクリック
2. 以下の権限を追加：
   - `im:message` — メッセージの送受信
   - `im:chat` — グループ情報の取得
   - `im:resource` — 画像・ファイルの送受信

## Step 5: アプリを公開

1. 左メニューから **「バージョン管理」** → **「新バージョンを作成」**
2. バージョン名を入力（例：`v1.0.0`）
3. 「申請」→ 承認を待つ（通常1分以内）

## Step 6: グループに追加

1. 飛書でチャットグループを開く
2. 「設定」→「グループメンバー」→「+」
3. アプリ名（例：`AIアシスタント`）を検索して追加

## Step 7: 設定ファイルを更新

`feishu-config.yaml` の該当フィールドを編集：

```yaml
feishu:
  app_id: "cli_xxxxxxxxxxxxxxxxxxx"    # Step 2 で取得
  app_secret: "xxxxxxxxxxxxxxxxxxxx"  # Step 2 で取得
```

## Step 8: エージェントを再起動

```bash
cd ~/openclaw-workspace
openclaw restart
```

## 動作確認

飛書のグループで `こんにちは` と送ってみてください。
AIエージェントが返信すれば設定完了です！
