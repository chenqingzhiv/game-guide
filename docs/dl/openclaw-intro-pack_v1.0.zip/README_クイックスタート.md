# OpenClaw 導入パック v1.0
## 5分で始めるAIエージェント開発

---

## 🎯 このパックでできること

このパックをダウンロードすると、あなた専用のAIエージェントチームが **5分で稼働** します。

```
あなた
  ↓ (質問・指示)
メインエージェント（統括）
  ├─ プロジェクトマネージャー（計画・進捗管理）
  ├─ フルスタックエンジニア（コード実装）
  ├─ ライターエージェント（文書作成）
  └─ アナリストエージェント（調査・分析）
```

---

## ⚡ クイックスタート（5分）

### 前提条件
- Node.js v18+（[ダウンロード](https://nodejs.org/)）
- Git
- npm（Node.jsに同梱）
- ターミナル（macOS: Terminal / Windows: PowerShell / Linux: bash）

### Step 1: ZIPを展開

```bash
# デスクトップなど、好きな場所に展開してください
cd ~/Desktop
unzip openclaw-intro-pack_v1.0.zip
cd openclaw-intro-pack
```

### Step 2: セットアップスクリプトを実行

```bash
bash setup.sh
```

スクリプトが自動で以下を行います：
1. ✅ 動作環境の確認（Node.js/Git/npm）
2. ✅ OpenClaw CLIのインストール（未インストールの場合）
3. ✅ ワークスペースの作成（`~/openclaw-workspace/`）
4. ✅ 5つのエージェントプロファイルをインストール

**所要時間：約2分（回線速度によります）**

### Step 3: エージェントを起動

```bash
cd ~/openclaw-workspace
openclaw start
```

### Step 4: 動いているか確認

```bash
openclaw status
```

以下のような表示が出れば成功です：
```
✅ main-agent         active
✅ project-manager    active
✅ fullstack-engineer active
✅ writer-agent       active
✅ analyst-agent      active
```

---

## 📁 ファイル構成

```
openclaw-intro-pack/
├── setup.sh                    # セットアップスクリプト
├── README_クイックスタート.md  # このファイル
│
├── 02_エージェントプロファイル/
│   ├── main-agent_SOUL.md
│   ├── project-manager_SOUL.md
│   ├── fullstack-engineer_SOUL.md
│   ├── writer-agent_SOUL.md
│   └── analyst-agent_SOUL.md
│
├── 03_飛書連携/
│   ├── feishu-config.yaml
│   └── 飛書Bot設定手順.md
│
├── 04_LINE連携/
│   └── line-config.yaml
│
├── 05_マルチエージェント/
│   ├── multi-agent-config.yaml
│   └── routing-guide.md
│
├── 06_ツール権限設定/
│   └── permissions.yaml
│
└── 07_トレーディングエージェント/
    ├── trading-cron-config.yaml
    └── trading-agent_SOUL.md
```

---

## 🔌 飛書（Feishu/Lark）連携

飛書と連携すると、チームメンバーが飛書から直接AIエージェントと会話できます。

### 設定手順

**所要時間：5分**

1. [飛書開放平台](https://open.feishu.cn/app) にアクセス
2. 「アプリを作成」→ 名前を入力（例：AIアシスタント）
3. 「アプリID」「アプリSecret」をコピー
4. `03_飛書連携/feishu-config.yaml` の `app_id` と `app_secret` に貼り付け
5. イベント購読: `im.message.receive_v1` を追加
6. 権限設定: `im:message` を追加
7. アプリを公開 → グループに追加

詳細は `03_飛書連携/飛書Bot設定手順.md` を参照してください。

---

## 🆘 トラブルシューティング

### Node.js がインストールされていない
```
Error: Node.js が見つかりません
```
→ https://nodejs.org から v18 LTS をダウンロード＆インストール

### 既にOpenClawがインストールされている
スクリプトが自動検出して「アップデートしますか？」と聞きます。
安定して動いている場合は `n` を入力してスキップしてください。

### ポートが既に使用中
```
Error: listen EADDRINUSE :::xxxx
```
→ `openclaw stop` で停止してから再試行

### プロファイルが読み込めない
```bash
# 強制的に再インストール
cd ~/openclaw-workspace
openclaw profile install ~/openclaw-intro-pack/02_エージェントプロファイル/*.md
```

---

## 📞 サポート

- X (Twitter): [@qingzhijiang](https://x.com/qingzhijiang)
- お問い合わせはDMください（24時間以内に返信）
- よくある質問はNote記事でも随時更新予定

---

*OpenClaw 導入パック v1.0 — Copyright (C) 2026 Qingzhi Jiang*
