#!/bin/bash
# ======================================================
# OpenClaw 導入パック — セットアップスクリプト
# 対象: macOS / Linux / WSL
# 実行方法: bash setup.sh
# ======================================================
set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info()  { echo -e "${GREEN}[✓]${NC} $1"; }
warn()  { echo -e "${YELLOW}[!]${NC} $1"; }
err()   { echo -e "${RED}[✗]${NC} $1"; }

echo ""
echo "=============================================="
echo "  OpenClaw 導入パック v1.0"
echo "  5分で始めるAIエージェント開発"
echo "=============================================="
echo ""

# ---- Step 1: 前提確認 ----
echo "【Step 1/4】前提環境を確認中..."

if command -v node &>/dev/null; then
    NODE_VER=$(node -v)
    info "Node.js: $NODE_VER"
else
    err "Node.js が見つかりません。https://nodejs.org から v18+ をインストールしてください。"
    exit 1
fi

if command -v git &>/dev/null; then
    info "Git: $(git --version)"
else
    err "Git が見つかりません。"
    exit 1
fi

if command -v npm &>/dev/null; then
    info "npm: $(npm -v)"
else
    err "npm が見つかりません。"
    exit 1
fi

# ---- Step 2: OpenClaw CLI インストール ----
echo ""
echo "【Step 2/4】OpenClaw CLI をインストール中..."

if command -v openclaw &>/dev/null; then
    OPENCLAW_VER=$(openclaw --version 2>/dev/null || echo "unknown")
    info "OpenClaw は既にインストールされています: $OPENCLAW_VER"
    echo "  最新版にアップデートしますか？ [Y/n] "
    read -r UPGRADE_ANS
    UPGRADE_ANS=${UPGRADE_ANS:-Y}
    if [[ "$UPGRADE_ANS" =~ ^[Yy] ]]; then
        npm install -g @openclaw/cli@latest
        info "OpenClaw を最新版にアップデートしました"
    fi
else
    echo "  OpenClaw CLI をインストールしています..."
    npm install -g @openclaw/cli@latest
    info "OpenClaw CLI のインストールが完了しました"
fi

# ---- Step 3: ワークスペース設定 ----
echo ""
echo "【Step 3/4】ワークスペースを初期化中..."

WORKSPACE_DIR="${HOME}/openclaw-workspace"
if [ -d "$WORKSPACE_DIR" ]; then
    warn "ワークスペース '$WORKSPACE_DIR' は既に存在します"
    echo "  上書きしますか？ [y/N] "
    read -r OVERWRITE_ANS
    if [[ ! "$OVERWRITE_ANS" =~ ^[Yy] ]]; then
        warn "スキップします。既存のワークスペースをお使いください。"
    else
        rm -rf "$WORKSPACE_DIR"
        openclaw init "$WORKSPACE_DIR"
        info "ワークスペースを初期化しました: $WORKSPACE_DIR"
    fi
else
    openclaw init "$WORKSPACE_DIR"
    info "ワークスペースを作成しました: $WORKSPACE_DIR"
fi

# ---- Step 4: プロファイル導入 ----
echo ""
echo "【Step 4/4】エージェントプロファイルをインストール中..."

PROFILES_DIR="$(dirname "$0")/../02_エージェントプロファイル"

if [ -d "$PROFILES_DIR" ]; then
    mkdir -p "${WORKSPACE_DIR}/profiles"
    cp -r "$PROFILES_DIR"/*.md "${WORKSPACE_DIR}/profiles/" 2>/dev/null || true

    for profile in "${WORKSPACE_DIR}/profiles"/*.md; do
        name=$(basename "$profile" .md)
        info "プロファイルをインストール: $name"
    done
else
    warn "プロファイルディレクトリが見つかりません。手動でコピーしてください。"
fi

# ---- 飛書設定コピー ----
FEISHU_DIR="$(dirname "$0")/../03_飛書連携"
if [ -d "$FEISHU_DIR" ]; then
    mkdir -p "${WORKSPACE_DIR}/config"
    cp -r "$FEISHU_DIR"/*.yaml "${WORKSPACE_DIR}/config/" 2>/dev/null || true
    info "飛書連携設定をコピーしました"
fi

# ---- マルチエージェント設定コピー ----
MA_DIR="$(dirname "$0")/../05_マルチエージェント"
if [ -d "$MA_DIR" ]; then
    cp -r "$MA_DIR"/*.yaml "${WORKSPACE_DIR}/config/" 2>/dev/null || true
    info "マルチエージェント設定をコピーしました"
fi

# ---- 完了 ----
echo ""
echo "=============================================="
echo "  ✅ セットアップ完了！"
echo "=============================================="
echo ""
echo "  ワークスペース: ${WORKSPACE_DIR}"
echo ""
echo "  次のステップ:"
echo "  1. cd ${WORKSPACE_DIR}"
echo "  2. openclaw start                  # エージェント起動"
echo "  3. openclaw status                 # 状態確認"
echo ""
echo "  詳細は README_クイックスタート.md を参照してください。"
echo ""
